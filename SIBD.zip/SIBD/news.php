 <?php
		include ('templates/header.php');
		include('templates/news.php');
		include('templates/footer.php');
  ?>