<?php
	include ('config/init.php');
	include ('database/follows.php');
  
	$slave = $_SESSION['username'];
	$master = $_GET['owner'];
	
	if(!isFollowing($slave, $master)){
		startFollowing($slave, $master);	
	}
	else stopFollowing($slave, $master);
	
	header('Location: ' . $_SERVER['HTTP_REFERER']);
?>