<?php
	include ('config/init.php');
	include('database/rumor.php');

	$_SESSION['id']=$_GET['rumor_id'];
	$rumor=getrumorById($_SESSION['id']);
	include('view_rumor.php');
?>