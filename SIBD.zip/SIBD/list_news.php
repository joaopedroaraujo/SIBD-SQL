<?php
		session_start();
		include ('config/init.php');
		include ('templates/header.php');
		include ('database/news.php');
		include ('database/like_dislike.php');
		
		if(exist_news()){
		$news_vector = list_news();
		include ('templates/list_news.php');}
		
		else 
			echo ("No news uploaded yet...");
		
		include ('templates/footer.php');
?>