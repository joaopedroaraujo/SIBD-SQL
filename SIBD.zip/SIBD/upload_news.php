<?php
		include ('templates/header.php');
		include ('templates/upload_news.php');
		include ('templates/footer.php');
?>