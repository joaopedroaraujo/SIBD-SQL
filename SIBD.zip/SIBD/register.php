<?php
		$username = isset($_FORM_VALUES['username'])?$_FORM_VALUES['username']:'';
		include ('templates/header.php');
		include ('templates/register.php');
		include ('templates/footer.php');
?>