<?php
  include ('config/init.php');
  include ('database/comment.php');

  $post_id = $_SESSION['post_id'];
  $user_id = $_SESSION['username'];
  $comment = $_POST['comment'];
  
  addComment($post_id, $comment, $user_id);
  
  header('Location: ' . $_SERVER['HTTP_REFERER']);
?>