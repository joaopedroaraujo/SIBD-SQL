 <?php
		include ('templates/header.php');
		include('templates/view_news.php');
		include('templates/footer.php');
  ?>