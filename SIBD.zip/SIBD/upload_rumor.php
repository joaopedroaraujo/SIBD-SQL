<?php
		include ('templates/header.php');
		include ('templates/upload_rumor.php');
		include ('templates/footer.php');
?>