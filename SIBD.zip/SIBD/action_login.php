<?php
  include ('config/init.php');
  include ('database/user.php');

  $username = $_POST['username'];
  $password = $_POST['password'];

  if (isValidUser($username, $password)) {
    $_SESSION['success_message'] = 'Login successful!';
    $_SESSION['username'] = $username;
	header('Location: index.php');
  }
  else {
	if(isset($_SESSION['admin'])) header('Location: index.php');
	else {
		$_SESSION['error_message'] = 'Login failed!';
		header('Location: login.php');
	}
  }

?>
