 <?php
		include ('config/init.php');
		include('database/post.php');
		include ('templates/header.php');
		
		$post_id = $_GET['post_id'];
		$type = $_GET['type'];
		$_SESSION['post_id']=$post_id;
		$_SESSION['type']=$type;
		$post = getPostById($type, $post_id);
		
		include('templates/view_post.php');
		include('templates/footer.php');
  ?>