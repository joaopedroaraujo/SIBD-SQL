 <?php
		include ('config/init.php');
		include_once('database/post.php');
		include_once ('database/like_dislike.php');
		include_once ('database/comment.php');
		include ('templates/header.php');
		
		if (isset($_GET['post_id'])){
			$post_id = $_GET['post_id'];
			$_SESSION['post_id']=$post_id;
		}
		else $post_id=$_SESSION['post_id'];
		
		if (isset($_GET['type'])){
			$type = $_GET['type'];
			$_SESSION['type']=$type;
		}
		else $type=$_SESSION['type'];
		
		$post = getPostById($post_id);
		
		include('templates/view_post.php');
		include('templates/footer.php');
  ?>