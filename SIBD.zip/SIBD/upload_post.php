<?php
		include ('templates/header.php');
		
		$type=$_GET['type'];
		
		include ('templates/upload_post.php');
		include ('templates/footer.php');
?>