<?php
  session_start();
  include ('config/init.php');
  include_once ('database/comment.php');
  include_once ('database/post.php');
  include_once ('database/user.php');

  $remove = $_GET['entity'];
  $type = $_SESSION['type'];
  $remove_comment = substr($remove, 0, 7);
  //$remove_comment = $_POST['entity'];
  $post_id = $_SESSION['post_id'];
  $user_id = $_SESSION['username'];
  $owner = $_SESSION['owner'];
  
  if($remove_comment == "comment"){
	$comment_id = substr($remove, 7);
	//$number = getCommentNumber($remove_comment);
	removeComment($comment_id);
	header('Location: ' . $_SERVER['HTTP_REFERER']);
	//echo json_encode($number);
  }
  
  if ($remove === "post"){
	removePost($post_id, $type);
	header("Location: list_posts.php?type=$type");
  }
  if ($remove === "user"){
	if(isAdmin($user_id)){
		$user_id = $owner;
		removeUser($user_id);
		header('Location: index.php');
	}
	else{
		removeUser($user_id);
		include ('action_logout.php');
	}
  }

?>