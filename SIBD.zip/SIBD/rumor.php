 <?php
		include ('templates/header.php');
		include('templates/rumor.php');
		include('templates/footer.php');
  ?>