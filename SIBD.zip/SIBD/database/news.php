<?php
  function uploadNews($category, $title, $news, $username) {
    global $conn;
	$stmt = $conn->prepare('INSERT INTO news VALUES (DEFAULT, ?, ?, ?, NOW(), ?)');
    $stmt->execute(array($category, $title, $news, $username));
  }
  
  function list_news(){
	global $conn;
	$stmt = $conn->prepare('SELECT * FROM news ORDER BY id DESC');
	$stmt->execute();
    return $stmt->fetchAll();
  }

  function exist_news(){
	global $conn;
	$stmt = $conn->query('SELECT * FROM news');
    if ($stmt->rowCount() > 0) return true;
	else return false;
  }
  
  function getNewsById($id) {
    global $conn;
	
    $stmt = $conn->prepare('SELECT * FROM news WHERE id = ?');
    $stmt->execute(array($id));
    return $stmt->fetch();
  }
?>