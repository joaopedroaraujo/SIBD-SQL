<?php
   include_once ('database/like_dislike.php');
   include_once ('database/comment.php');

  function uploadPost($type, $category, $title, $text, $username) {
    global $conn;
	$stmt = $conn->prepare('INSERT INTO posts VALUES (DEFAULT, ?, ?, ?, ?, NOW(), ?)');
    $stmt->execute(array($type, $category, $title, $text, $username));
  }
  
  function list_posts($type){
	global $conn;
	$stmt = $conn->prepare('SELECT * FROM posts WHERE type = ? ORDER BY id DESC');
	$stmt->execute(array($type));
    return $stmt->fetchAll();
  }
  
  function list_lattest_uploads($PAGE_SIZE){
	global $conn;
    $stmt = $conn->query('SELECT * FROM posts ORDER BY id DESC LIMIT '.$PAGE_SIZE.'');
    return $stmt->fetchAll();
  }
  
   function list_posts_by_category($category){
	global $conn;
	$stmt = $conn->prepare('SELECT * FROM posts WHERE category = ? ORDER BY id DESC');
	$stmt->execute(array($category));
    return $stmt->fetchAll();
  }

  function exist_post($type){
	global $conn;
	$stmt = $conn->prepare('SELECT * FROM posts WHERE type = ?');
	$stmt->execute(array($type));
    if ($stmt->rowCount() > 0) return true;
	else return false;
  }
  
  function getPostById($id) {
    global $conn;
    $stmt = $conn->prepare('SELECT * FROM posts WHERE id = ?');
    $stmt->execute(array($id));
    return $stmt->fetch();
  }
  
  function getPostsByUser($user_id) {
    global $conn;
    $stmt = $conn->prepare('SELECT * FROM posts WHERE user_id = ?');
    $stmt->execute(array($user_id));
    return $stmt->fetchAll();
  }
  
  function getPostsByCategory($category) {
    global $conn;
    $stmt = $conn->prepare('SELECT * FROM posts WHERE category = ?');
    $stmt->execute(array($category));
    return $stmt->fetchAll();
  }
  
  function exist_post_in_category($category){
	global $conn;
	$stmt = $conn->prepare('SELECT * FROM posts WHERE category = ?');
	$stmt->execute(array($category));
    if ($stmt->rowCount() > 0) return true;
	else return false; 
	}
  
  function removePost($post_id, $type){
		removeAllPostLike_Dislike($post_id);
		removeAllPostComment($post_id);
		global $conn;
		$stmt = $conn->prepare('DELETE FROM posts WHERE id = ?');
		$stmt->execute(array($post_id));
		unlink("images/post/$type/display_images/$post_id.jpg");
		unlink("images/post/$type/original/$post_id.jpg");
	}
	
	function getAllPosts(){
		global $conn;
		$stmt = $conn->query('SELECT * FROM posts');
		return $stmt->fetchAll();
	}
?>