<?php
  function uploadPost($type, $category, $title, $text, $username) {
    global $conn;
	$stmt = $conn->prepare('INSERT INTO posts VALUES (DEFAULT, ?, ?, ?, ?, NOW(), ?)');
    $stmt->execute(array($type, $category, $title, $text, $username));
  }
  
  function list_posts($type){
	global $conn;
	$stmt = $conn->prepare('SELECT * FROM posts WHERE type = ? ORDER BY id DESC');
	$stmt->execute(array($type));
    return $stmt->fetchAll();
  }

  function exist_post($type){
	global $conn;
	$stmt = $conn->prepare('SELECT * FROM posts WHERE type = ?');
	$stmt->execute(array($type));
    if ($stmt->rowCount() > 0) return true;
	else return false;
  }
  
  function getPostById($type, $id) {
    global $conn;
	
    $stmt = $conn->prepare('SELECT * FROM posts WHERE type = ? AND id = ?');
    $stmt->execute(array($type, $id));
    return $stmt->fetch();
  }
?>