<?php 
	function addComment($post_id, $type, $comment, $user_id){
		global $conn;
		$stmt = $conn->prepare('INSERT INTO comments VALUES (DEFAULT, ?, ?, ?, NOW(), ?)');
		$stmt->execute(array($post_id, $type, $comment, $user_id));
	}
	
	function list_comments($post_id, $type){
	global $conn;
	$stmt = $conn->prepare('SELECT * FROM comments WHERE post_id = ? AND type = ? ORDER BY id DESC');
	$stmt->execute(array($post_id, $type));
    return $stmt->fetchAll();
  }
  
  function numberOfComments($post_id, $type){
		global $conn;
		$stmt = $conn->prepare('SELECT * FROM comments WHERE post_id = ? AND type = ?');
		$stmt->execute(array($post_id, $type));
		$numberOfComments=$stmt->rowCount();
		return $numberOfComments;
	}
?>