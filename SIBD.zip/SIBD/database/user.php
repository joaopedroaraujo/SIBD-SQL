<?php

  function isValidUser($username, $password) {
    global $conn;
	
    $stmt = $conn->prepare('SELECT * FROM users WHERE username = ?');
    $stmt->execute(array($username));
    
    $user = $stmt->fetch();
	$_SESSION['admins']=$user['admins'];

    return $user !== false && password_verify($password, $user['password']);
  }

  function createUser($username, $password, $password_repeat) {
	if ($password !== $password_repeat)	die(header('Location: register.php'));
	
    global $conn;

	$_SESSION['username'] = $username;
	$_SESSION['admins'] = 0;
	
    $options = [
        'cost' => 12,
    ];

    $hash = password_hash ($password , PASSWORD_DEFAULT, $options);

    $stmt = $conn->prepare('INSERT INTO users VALUES (?, ?, ?)');
    $stmt->execute(array($username, $hash, $_SESSION['admins']));
  }
?>
