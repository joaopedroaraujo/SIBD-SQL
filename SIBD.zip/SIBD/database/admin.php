<?php
	function checkadmin($username){
		global $conn;

		$stmt = $conn->prepare('SELECT * FROM admins WHERE username = ?');
		$stmt->execute(array($username));
		
		$test = $stmt->fetch();
		
		if(isset($test)) return true;
		
		else return false;
	}
	
	function isValidAdmin($username, $password) {
		global $conn;

		$stmt = $conn->prepare('SELECT * FROM admins WHERE username = ?');
		$stmt->execute(array($username));
		
		$test = $stmt->fetch();
		
		if($username === $test['username'] && $password === $test['password']){
			return true;
		}
		
		else return false;
  }
?>