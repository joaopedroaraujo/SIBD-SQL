<?php

	function liked($post_id, $user_id, $type){
		global $conn;
		$stmt = $conn->prepare('SELECT * FROM likes_dislikes WHERE post_id = ? AND type = ? AND user_id = ?');
		$stmt->execute(array($post_id, $type, $user_id));
		$like=$stmt->fetch();
		if($like['likes'] === 1) return true;
		else return false;
	}

	function addLike($post_id, $user_id, $type){
		removeLike_Dislike($post_id, $user_id);
		global $conn;
		$stmt = $conn->prepare('INSERT INTO likes_dislikes VALUES (DEFAULT, ?, ?, 1, 0, NOW(), ?)');
		$stmt->execute(array($post_id, $type, $user_id));
	}
	
	function disliked($post_id, $user_id, $type){
		global $conn;
		$stmt = $conn->prepare('SELECT * FROM likes_dislikes WHERE post_id = ? AND type = ? AND user_id = ?');
		$stmt->execute(array($post_id, $type, $user_id));
		$dislike=$stmt->fetch();
		if($dislike['dislikes'] === 1)
			return true;
		else return false;
	}
	
	function addDislike($post_id, $user_id, $type){
		removeLike_Dislike($post_id, $user_id);
		global $conn;
		$stmt = $conn->prepare('INSERT INTO likes_dislikes VALUES (DEFAULT, ?, ?, 0, 1, NOW(), ?)');
		$stmt->execute(array($post_id, $type, $user_id));
	}

	function removeLike_Dislike($post_id, $user_id, $type){
		global $conn;
		$stmt = $conn->prepare('DELETE FROM likes_dislikes WHERE post_id = ? AND user_id = ?');
		$stmt->execute(array($post_id, $user_id));
	}
	
	function numberOfLikes($post_id, $type){
		global $conn;
		$stmt = $conn->prepare('SELECT * FROM likes_dislikes WHERE post_id = ? AND type = ? AND likes = 1');
		$stmt->execute(array($post_id, $type));
		$numberOfLikes=$stmt->rowCount();
		return $numberOfLikes;
	}
	
	function numberOfDislikes($post_id, $type){
		global $conn;
		$stmt = $conn->prepare('SELECT * FROM likes_dislikes WHERE post_id = ? AND type = ? AND dislikes = 1');
		$stmt->execute(array($post_id, $type));
		$numberOfLikes=$stmt->rowCount();
		return $numberOfLikes;
	}
	
	function userEvaluation($user_id){
		$n_likes=0;
		$n_dislikes=0;
		global $conn;
		$stmt = $conn->prepare('SELECT * FROM posts WHERE user_id = ?');
		$stmt->execute(array($user_id));
		$stmt->fetch();
		$posts=$stmt;
		foreach ($posts as $post){
			$post_id=$post['id'];
			$type=$post['type'];
			$n_likes=$n_likes+numberOfLikes($post_id, $type);
			$n_dislikes=$n_dislikes+numberOfDislikes($post_id, $type);
		}
		
		/*echo $n_dislikes;
		die();*/
		if(($n_likes+$n_dislikes)===0) return 0;
		else return ((($n_likes-$n_dislikes)/($n_likes+$n_dislikes))*100);
	}
?>