CREATE TABLE users (
  username VARCHAR PRIMARY KEY,
  password VARCHAR,
  admins INTEGER
);

CREATE TABLE rumors (
  id SERIAL PRIMARY KEY,
  category VARCHAR,
  title VARCHAR,
  text VARCHAR,
  date_time TIMESTAMP,
  user_id VARCHAR REFERENCES users
);

CREATE TABLE news (
  id SERIAL PRIMARY KEY,
  category VARCHAR,
  title VARCHAR,
  text VARCHAR,
  date_time TIMESTAMP,
  user_id VARCHAR REFERENCES users
);

CREATE TABLE likes_dislikes (
  id SERIAL PRIMARY KEY,
  post_id VARCHAR,
  likes INTEGER,
  dislikes INTEGER,
  date_time TIMESTAMP,
  user_id VARCHAR REFERENCES users
);

CREATE TABLE comments (
  id SERIAL PRIMARY KEY,
  comment VARCHAR,
  date_time TIMESTAMP,
  owner VARCHAR,
  user_id VARCHAR REFERENCES users
);

INSERT INTO users  VALUES ('ppinto','$2y$12$Layk.bcQLBGM5bodjPJbjORSUq1RwFDMKzfsrqLtX1obpzmK2mrB.', 1); /* ppinto */
INSERT INTO users  VALUES ('jaraujo','$2y$12$aDUpNopPWRZ987j/aa55/OhHNd0wW9S9CSXai7SX86ygjDbHFx/UG', 1); /* jaraujo */
