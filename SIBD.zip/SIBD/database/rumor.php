<?php

  function uploadRumor($category, $title, $rumor, $username) {
    global $conn;
	$stmt = $conn->prepare('INSERT INTO rumors VALUES (DEFAULT, ?, ?, ?, NOW(), ?)');
    $stmt->execute(array($category, $title, $rumor, $username));
  }
  
  function list_rumors(){
	global $conn;
	$stmt = $conn->prepare('SELECT * FROM rumors ORDER BY id DESC');
	$stmt->execute();
    return $stmt->fetchAll();
  }

  function exist_rumor(){
	global $conn;
	$stmt = $conn->query('SELECT * FROM rumors');
    if ($stmt->rowCount() > 0) return true;
	else return false;
  }
  
  function getRumorById($id) {
    global $conn;
	
    $stmt = $conn->prepare('SELECT * FROM rumors WHERE id = ?');
    $stmt->execute(array($id));
    return $stmt->fetch();
  }
?>