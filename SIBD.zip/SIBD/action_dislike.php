<?php
  include ('config/init.php');
  include ('database/like_dislike.php');

  $post_id = $_SESSION['id'];
  $user_id = $_SESSION['username'];
  
  if(!disliked($post_id, $user_id))
	addDislike($post_id, $user_id);

  else removeLike_Dislike($post_id, $user_id);
  
  header('Location: ' . $_SERVER['HTTP_REFERER']);
?>