<?php
	include ('config/init.php');
	include ('templates/header.php');
	include ('database/like_dislike.php');
	include ('database/user.php');

	$owner=$_GET['owner_id'];
		
	include ('templates/profile.php');
	include ('templates/footer.php');
?>