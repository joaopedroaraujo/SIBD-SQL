<?php
	include ('templates/header.php');
	include ('templates/profile.php');
	include ('templates/footer.php');
?>