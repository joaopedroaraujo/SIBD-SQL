<?php
	include ('config/init.php');
	include('database/rumor.php');

	$owner=$_GET['owner_id'];
	$username = $_SESSION['username'];
	$rumor=getrumorById($_SESSION['id']);
	include('view_rumor.php');
?>