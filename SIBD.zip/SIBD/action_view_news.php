<?php
	include ('config/init.php');
	include('database/news.php');

	$id=$_GET['news_id'];
	$news=getNewsById($id);
	include('view_news.php');
?>