<?php 
	include ('database/like_dislike.php');
	include ('database/comment.php');
	if (isset($_SESSION['username']))
		$user_id = $_SESSION['username'];
?>
<article>
  <header>
	<h1><?= $post['title']?></h1>
	<h2><?= $post['category']?></h2>
  </header>
  <img src="images/post/<?=$type?>/display_images/<?=$post_id?>.jpg">
  <p><?php echo $post['text'] ?></p>
  <p>
	<?="by"?> 
	<?=$post['user_id']?>
	<?="on"?> 
	<?php 
		$datetime = strtotime($post['date_time']);
		$final = date("l - d M Y, h:m A", $datetime);
	?>
	<?=$final?>
  </p>
  <p>Likes:<?= numberOfLikes($post_id, $type)?> Dislikes:<?= numberOfDislikes($post_id, $type)?><p>
  <?php if (isset($user_id)) : ?>
	  <?php if(!liked($post_id, $user_id, $type)) : ?>
		<a href="action_like.php"><button>Like</button></a>
	  <?php else : ?>
		<a href="action_like.php"><button>Liked</button>
	  <?php endif ;?>
	  <?php if(!disliked($post_id, $user_id, $type)) : ?>
		<a href="action_dislike.php"><button>Dislike</button></a>
	  <?php else : ?>
		<a href="action_dislike.php"><button>Disliked</button></a>
	  <?php endif ;?>
	  <br>
	  <form method="post" action="action_comment.php">
		  <label><b>Comments:</b></label>
		  <br>
		  <textarea rows="7" cols="150" name="comment" required></textarea>
		  <br>
		  <input type="submit" value="Submit comment">
	  </form>
	  <?php $comments = list_comments($post_id, $type); ?>
		<?php foreach ($comments as $comment) { ?>
			<a href="profile.php?owner_id=<?=$comment['user_id']?>"><?=$comment['user_id']?></a>
			<p><?=$comment['comment']?></p>
		<?php } ?>
  <?php else : ?>
	<p><b>Comments:</b></p>
		<?php $comments = list_comments($post_id, $type); ?>
		<?php foreach ($comments as $comment) { ?>
			<a href="profile.php?owner_id=<?=$comment['user_id']?>"><?=$comment['user_id']?></a>
			<p><?=$comment['comment']?></p>
		<?php } ?>
	<p> <a href="register.php">Register</a> or <a href="login.php">login<a> to share an opinion! </p>
  <?php endif ;?>
</article>