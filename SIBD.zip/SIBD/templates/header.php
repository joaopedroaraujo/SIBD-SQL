<?php 
	if (session_status() == PHP_SESSION_NONE) {
    session_start();
	}
?>

<!DOCTYPE html> 
<html lang="en">
  <head>
      <link href="css/initial.css" rel="stylesheet">
      <meta charset="UTF-8">
      <title>TechLatest</title>
  </head>
  <body>
	<?php if(isset($_SESSION['username']) || isset($_SESSION['success_message'])) : ?>
		<div id="signup">
			<?php if($_SESSION['admins']===1) : ?>
			<a href="upload_news.php"><button>Upload news</button></a>
			<?php endif; ?>
			<a href="upload_rumor.php"><button>Upload rumor</button></a>
			<a href="profile.php"><img src="images/user/thumbs_small/<?php echo($_SESSION['username']) ?>.jpg"></a>
			<a href="profile.php"><?php echo($_SESSION['username']); ?></a>
			<a href="action_logout.php">Logout</a>
		</div>
	<?php else : ?>
		<div id="signup">
			<a href="register.php">Register</a>
			<a href="login.php">Login</a>
		</div>
	<?php endif; ?>
    <nav>
          <table>
              <tr>
                  <th><a href="initial.html">Smartphones</a></th>
                  <th><a href="initial.html">Computers</a></th>
                  <th><a href="initial.html">Tablets</a></th>
                  <th><a href="initial.html">Google</a></th>
                  <th><a href="initial.html">Apple</a></th>
                  <th><a href="initial.html">Android</a></th>
                  <th><a href="initial.html">iOS</a></th>
                  <th><a href="initial.html">Others</a></th>
              </tr>
          </table>
      </nav>
      <div id="title">
        <header>
            <h1><a href="index.php">TechLatest</a></h1>
            <h2><a href="index.php">News and rumors you care about</a></h2>
        </header>
      </div>
      <nav>
          <table>
              <tr>
                  <th><a href="list_rumors.php">Rumors</a></th>
                  <th><a href="list_news.php">News</a></th>
                  <th><a href="initial.html">Reviews</a></th>
                  <th><a href="initial.html">Buyer's guide</a></th>
                  <th> <input type="text" name="search" placeholder="Search.."></th>
              </tr>
          </table>
      </nav>