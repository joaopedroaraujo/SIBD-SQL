<article>
  <header>
	<h1><?= $news['title']?></h1>
	<h2><?= $news['category']?></h2>
  </header>
  <img src="images/news/display_images/<?=$news['id']?>.jpg">
  <p><?php echo $news['text'] ?></p>
  <p>
	<?="by"?> 
	<?=$news['user_id']?>
	<?="on"?> 
	<?php 
		$datetime = strtotime($news['date_time']);
		$final = date("l - d M Y, h:m A", $datetime);
	?>
	<?=$final?>
  </p>
  <a href="action_like_dislike"><button>Like</button></a>
  <a href="action_like_dislike"><button>Dislike</button></a>
  <br>
  <label><b>Comments:</b></label>
  <br>
  <textarea rows="7" cols="150" name="news" required></textarea>
  <br>
  <input type="submit" value="Submit comment">
</article>