<header>
	<h1><?= $type?>'s form:<h1>
</header>
<form method="post" action="action_upload_post.php?type=<?= $type?>" enctype="multipart/form-data">
	<label>Category</label>
	<select name="category">
	  <option value="smartphones">Smartphones</option>
	  <option value="computers">Computers</option>
	  <option value="tablets">Tablets</option>
	  <option value="google">Google</option>
	  <option value="apple">Apple</option>
	  <option value="android">Android</option>
	  <option value="ios">iOS</option>
	  <option value="others">Others</option>
	</select>
	<br>
	<label><b>Title</b></label>
	<input type="text" name="title" maxlength="90" required>
	<br>
	<textarea rows="30" cols="150" name="text" placeholder="Write your <?= $type?>" required></textarea>
	<br>
	<label>Picture (optional)</label>
	<input type="file" name="image">
	<br>
	<input type="submit" value="Submit <?= $type?>">
</form>