	  <aside id="related">
          <header>
              <p>Latest uploads</p>
          </header>
		  <?php foreach($lattests as $lattest){?>
          <article>
			<header>
              <h1><a href="view_post.php?post_id=<?=$lattest['id']?>&type=<?=$lattest['type']?>"><?= $lattest['title'];?></a></h1>
            </header>  
			 <a href="view_post.php?post_id=<?=$lattest['id']?>&type=<?=$lattest['type']?>"><img src="images/post/<?=$lattest['type']?>/display_images/<?=$lattest['id']?>.jpg"></a>
			 <p>Type:<a href="list_posts.php?type=<?=$lattest['type']?>"><?= $lattest['type'];?></a></p>
		  </article>
		  <?php } ?>
      </aside>
      <section id="news">
		<header>Trending</header>
		<?php for($i = 0; $i < $numberOfPostsTrending; $i++){ 
				$maxs = array_keys($numberOfReactions, max($numberOfReactions));
				$id = $post_id[$maxs[0]];
				$post = getPostById($id);?>
          <article <?php if(isset($_SESSION['first_news'])) : ?> id="firstnews" <?php else :?> id="otherNews" <?php endif; ?>>
              <header>
                <h1><a href="view_post.php?post_id=<?=$post['id']?>&type=<?=$post['type']?>"><?= $post['title'];?></a></h1>
              </header>
              <a href="view_post.php?post_id=<?=$post['id']?>&type=<?=$post['type']?>"><img src="images/post/<?=$post['type']?>/display_images/<?=$post['id']?>.jpg"></a>
			  <p>Type:<a href="list_posts.php?type=<?=$post['type']?>"><?= $post['type'];?></a></p>
          </article>
		<?php unset($numberOfReactions[$maxs[0]]);}
			  unset($_SESSION['first_news'])?>
          </article>
      </section>