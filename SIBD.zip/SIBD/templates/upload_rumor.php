<header>
	<p>Rumor's form:</p>
</header>
<form method="post" action="action_upload_rumor.php" enctype="multipart/form-data">
	<label>Category</label>
	<select name="category">
	  <option value="smartphones">Smartphones</option>
	  <option value="computers">Computers</option>
	  <option value="tablets">Tablets</option>
	  <option value="google">Google</option>
	  <option value="apple">Apple</option>
	  <option value="android">Android</option>
	  <option value="ios">iOS</option>
	  <option value="others">Others</option>
	</select>
	<br>
	<label><b>Title</b></label>
	<input type="text" name="title" required>
	<br>
	<textarea rows="30" cols="150" name="rumor" placeholder="Write your rumor!" required></textarea>
	<br>
	<label>Picture (optional)</label>
	<input type="file" name="image">
	<br>
	<input type="submit" value="Submit rumor">
</form>