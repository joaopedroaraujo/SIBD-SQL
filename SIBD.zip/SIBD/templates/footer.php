	
		<footer>
			<p>&copy; TechLatest, 2017</p>
		</footer>
	</body>
</html>