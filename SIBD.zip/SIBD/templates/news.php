<body>
	<section>
          <article>
              <header>
                <h1>Samsung S9 first renders</h1>
              </header>
              <img id="image" src="images/Samsung-Galaxy-S9-2.jpg" alt="Samsung S9" width="300" height=auto>
              <p>The Samsung S8 and Note 8 is not out for a while but the first renders of the S9 are starting to appear as users dream with the ideal Galaxy.</p>
          </article>
	</section>
</body>