<form method="post" action="action_register.php">
  <div class="container">
	<label><b>Username</b>
		<input type="text" placeholder="Enter Username" name="username" required>
	</label>
		<br>
	<label><b>Password</b>
		<input type="password" placeholder="Enter Password" name="password" required>
	</label>
		<br>
	<label><b>Repeat Password</b>
		<input type="password" placeholder="Repeat Password" name="password_repeat" required>
	</label>
	<br>
	<a href="index.php"><button type="button"  class="cancelbtn">Cancel</button></a>
	<button type="submit">Next</button>
  </div>
</form>


