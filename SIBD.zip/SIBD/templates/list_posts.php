<?php ?>
		<nav>
			<?php if(isset($_SESSION['search'])) : 
			unset($_SESSION['search']); ?>
			<header><b>Posts:</b>
			<br>
			<?php endif; ?>
			<?php foreach ($posts as $post) { 
			$type=$post['type'];?>
			<a href="view_post.php?post_id=<?=$post['id']?>&type=<?=$type?>"><img src="images/post/<?=$type?>/display_images/<?=$post['id']?>.jpg"></a>
			<label><b>Title:</b><a href="view_post.php?post_id=<?=$post['id']?>"><?=$post['title']?></a></label>
			<br>
			<?php if(isset($category)) : ?>
				<label><b>Type:</b><a href="view_product.php?prod_id=<?=$product['id']?>"><?=$post['type']?></a></label>
			<?php else : ?>
				<label><b>Category:</b><a href="view_product.php?prod_id=<?=$product['id']?>"><?=$post['category']?></a></label>
			<?php endif; ?>
			<br>
		</nav>
		<p>Likes:<?= numberOfLikes($post['id'])?> Dislikes:<?= numberOfDislikes($post['id'])?><p>
		<p>Comments:<?=numberOfComments($post['id'])?></p>
<?php } ?>