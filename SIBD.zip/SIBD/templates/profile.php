<?php if(isset($_SESSION['username'])):
	$username = $_SESSION['username'];?>
	<?php if($owner === $username) : // if the user wants to go to his own profile' ?>
		<a href="edit_profile.php"><input type="button" value="Edit profile"></a>
	<?php endif; ?>
		<br>
		<?php if(!isAdmin($username)) : ?>
		<img src="images/user/thumbs_medium/<?= $owner?>.jpg"></a>
		<?php endif; ?>
		<p><b><?= $owner?></b></p>
		<!-- <p><b>Member since:<?= $owner?></b></p>  acabar--> 
		<p><b>Evaluation:<?= userEvaluation($owner)?></b></p>
<?php else :?>
	<img src="images/user/thumbs_medium/<?= $owner?>.jpg"></a>
	<p><b><?= $owner?></b></p>
	<!-- <p><b>Member since:<?= $owner?></b></p>  acabar--> 
	<p><b>Evaluation:<?= userEvaluation($owner)?></b></p>
<?php endif; ?>