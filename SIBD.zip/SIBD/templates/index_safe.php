<aside id="related">
          <header>
              <p>Latest news</p>
          </header>
          <article>
              <h1><a href="view_post.php?post_id=<?=$post['id']?>&type=<?=$type?>"><img src="images/post/<?=$type?>/display_images/<?=$post['id']?>.jpg">One Plus, with its newest flagship, is still the speed king</a></h1>
              <p>The just announced One Plus 5T is another important mark in the brand philology: amazing performance at reasonable pricing.</p>
              <img src="images/142555-phones-feature-oneplus-5t-release-date-specs-and-everything-you-need-to-know-image1-pvouqxwn7f.jpg" alt="OnePlus5T" width="100" height=auto>
          </article>
          <article>
              <h1><a href="#">Uber orders 24,000 Volvos for self-driving program</a></h1>
              <p>Back in 2016, Volvo and Uber partnered up to bring self-driving vehicles to the ride-hailing giant's fleet. Now, Uber is going all-in on that partnership with a big order.</p>
              <img src="images/uber-serp-logo-f6e7549c89.jpg" alt="Uber logo" width="100" height=auto>
          </article>
          <article>
              <h1><a href="#">Google home mini</a></h1>
              <p>The first attempt of Google to get into the smart homes market just got shrunk both in price and size.</p>
              <img src="images/dseifert_171008_2042_4560_02.1507723815.jpg" alt="Google home mini" width="100" height=auto>
          </article>
      </aside>
      <section id="news">
		  <header>Trending</header>
          <article id="firstnews">
              <header>
                <h1><a href="news.php">Samsung S9 first renders</a></h1>
              </header>
              <a href="news.php"><img id="image" src="images/Samsung-Galaxy-S9-2.jpg" alt="Samsung S9" width="300" height=auto></a>
              <p>The Samsung S8 and Note 8 is not out for a while but the first renders of the S9 are starting to appear as users dream with the ideal Galaxy.</p>
          </article>
          <article id="secondnews">
              <header>
                <h1><a href="#">iPhone X users start to discover some problems with the device</a></h1>
              </header>
              <img src="images/iphonexdesign-1-800x597.jpg" alt="iPhone X" width="300" height=auto>
              <!--<p>Nothing in this world is perfect, but when you pay almost the same for a smartphone as for a small car, it sure should be. Check out some of the first problems reported by users.</p>-->
          </article>
          <article id="thirdnews">
              <header>
                <h1><a href="#">Tesla roadster 0-100km/h (62 mph) production car record</a></h1>
              </header>
              <img src="images/raf6cpy8qocflnpjsa12.jpg" alt="Tesla roadster" width="300" height=auto>
              <!--<p>The new Tesla roadster (only ready for sale in 2020) just set a new record in acceleration from 0-100km/h(62mph) topping out the almighty Bugatti Chiron.</p>-->
          </article>
      </section>