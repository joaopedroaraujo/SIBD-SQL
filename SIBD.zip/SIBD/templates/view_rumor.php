<?php 
	include ('database/like_dislike.php');
	$post_id = $_SESSION['id'];
	if (isset($_SESSION['username']))
		$user_id = $_SESSION['username'];
?>
<article>
  <header>
	<h1><?= $rumor['title']?></h1>
	<h2><?= $rumor['category']?></h2>
  </header>
  <img src="images/rumor/display_images/<?=$rumor['id']?>.jpg">
  <p><?php echo $rumor['text'] ?></p>
  <p>
	<?="by"?> 
	<?=$rumor['user_id']?>
	<?="on"?> 
	<?php 
		$datetime = strtotime($rumor['date_time']);
		$final = date("l - d M Y, h:m A", $datetime);
	?>
	<?=$final?>
  </p>
  <?php if (isset($user_id)) : ?>
	  <p>Likes:<?= numberOfLikes($post_id)?> Dislikes:<?= numberOfDislikes($post_id)?><p>
	  <?php if(!liked($post_id, $user_id)) : ?>
		<a href="action_like.php"><button>Like</button></a>
	  <?php else : ?>
		<a href="action_like.php"><button>Liked</button>
	  <?php endif ;?>
	  <?php if(!disliked($post_id, $user_id)) : ?>
		<a href="action_dislike.php"><button>Dislike</button></a>
	  <?php else : ?>
		<a href="action_dislike.php"><button>Disliked</button></a>
	  <?php endif ;?>
	  <br>
	  <label><b>Comments:</b></label>
	  <br>
	  <textarea rows="7" cols="150" name="news" required></textarea>
	  <br>
	  <input type="submit" value="Submit comment">
  <?php else : ?>
    <p>Likes:<?= numberOfLikes($post_id)?> Dislikes:<?= numberOfDislikes($post_id)?><p>
	<p> Register or login to share an opinion! </p>
  <?php endif ;?>
</article>