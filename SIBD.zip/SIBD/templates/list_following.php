<section id="following">
	<?php foreach($masters as $master){
		  $posts = getPostsByUser($master['master']);
		  if(count($posts) === 0){
			echo "You are not following anyone or the users you are following have not posted anything yet...";
			include ('templates/footer.php');
		  }
		  else{
				foreach($posts as $post){;?>
				  <article>
					  <header>
						<h1><a href="view_post.php?post_id=<?=$post['id']?>&type=<?=$post['type']?>"><?= $post['title'];?></a></h1>
					  </header>
					  <a href="view_post.php?post_id=<?=$post['id']?>&type=<?=$post['type']?>"><img src="images/post/<?=$post['type']?>/display_images/<?=$post['id']?>.jpg"></a>
					  <p>Type:<a href="list_posts.php?type=<?=$post['type']?>"><?= $post['type'];?></a></p>
				  </article>
				<?php }
			include ('templates/footer.php');
		  }
	}?>
	  </article>
 </section>