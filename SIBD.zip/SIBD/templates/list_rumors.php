<?php foreach ($rumors as $rumor) { ?>
	<nav>
		<a href="action_view_rumor.php?rumor_id=<?=$rumor['id']?>"><img src="images/rumor/display_images/<?=$rumor['id']?>.jpg"></a>
		<label><b>Title:</b><a href="action_view_rumor.php?rumor_id=<?=$rumor['id']?>"><?=$rumor['title']?></a></label>
		<br>
		<label><b>Category:</b><a href="view_product.php?prod_id=<?=$product['id']?>"><?=$rumor['category']?></a></label>
		<p>Likes:<?= numberOfLikes($rumor['id'])?> Dislikes:<?= numberOfDislikes($rumor['id'])?><p>
	</nav>
<?php } ?>