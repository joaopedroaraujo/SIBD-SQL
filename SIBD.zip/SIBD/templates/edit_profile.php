<?php $username = $_SESSION['username']; ?>
<div>
	<label id="profile_pic">Profile picture:
		<input type="file" name="image">
	</label>
	<br>
	<label id="label_username">Username:
		<input type="text" placeholder="<?=$username?>" />
	</label>
	<br>
	<label id="label_password">New password: ...
		<input type="text" placeholder="<?="Password"?>" />
	</label>
	<br>
	<label id="label_repeat_password">Repeat new password: ...
		<input type="text" placeholder="<?="Password"?>" />
	</label>
	<br>
		<input class="submit" type="submit" value="Save Changes">
</div>