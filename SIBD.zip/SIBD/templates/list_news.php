<?php foreach ($news_vector as $news) { ?>
	<nav>
		<a href="action_view_news.php?news_id=<?=$news['id']?>"><img src="images/news/display_images/<?=$news['id']?>.jpg"></a>
		<label><b>Title:</b><a href="action_view_news.php?news_id=<?=$news['id']?>"><?=$news['title']?></a></label>
		<br>
		<label><b>Category:</b><a href="view_product.php?prod_id=<?=$product['id']?>"><?=$news['category']?></a></label>
	</nav>
<?php } ?>