<?php foreach ($rumors as $rumor) { ?>
	<article>
		<img src="images/rumor/display_images/<?=$rumor['id']?>.jpg">
		<label><b>Title:</b><a href="view_product.php?prod_id=<?=$product['id']?>"><?=$rumor['title']?></a></label>
		<br>
		<label><b>Category:</b><a href="view_product.php?prod_id=<?=$product['id']?>"><?=$rumor['category']?></a></label>
		| <p>
				<?php echo $rumor['text'] ?>
		  </p>
		<p>
			<?="by"?> 
			<?=$rumor['user_id']?>
			<?="on"?> 
			<?php 
				$datetime = strtotime($rumor['date_time']);
				$final = date("l - d M Y, h:m A", $datetime);
			?>
			<?=$final?>
		</p>
	</article>
<?php } ?>