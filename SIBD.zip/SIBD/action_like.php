<?php
  include ('config/init.php');
  include ('database/like_dislike.php');

  $post_id = $_SESSION['post_id'];
  $user_id = $_SESSION['username'];
  $type = $_SESSION['type'];
  
  if(!liked($post_id, $user_id, $type))
	addLike($post_id, $user_id, $type);

  else removeLike_Dislike($post_id, $user_id, $type);
  
  header('Location: ' . $_SERVER['HTTP_REFERER']);
?>