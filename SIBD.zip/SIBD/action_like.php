<?php
  include ('config/init.php');
  include ('database/like_dislike.php');

  $post_id = $_SESSION['post_id'];
  $user_id = $_SESSION['username'];
  
  if(!liked($post_id, $user_id))
	addLike($post_id, $user_id);

  else removeLike_Dislike($post_id, $user_id);
  
  header('Location: ' . $_SERVER['HTTP_REFERER']);
?>