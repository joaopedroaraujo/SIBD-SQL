<?php
		session_start();
		include ('config/init.php');
		include_once ('database/post.php');
		include_once ('database/like_dislike.php');
		include_once ('database/comment.php');
		include ('templates/header.php');
		
		$numberOfPostsLattest = 5;
		$lattests=list_lattest_uploads($numberOfPostsLattest);
		
		$posts = getAllPosts();
		$post_id = array();
		$numberOfReactions = array();
		$numberOfPostsTrending = 0;
		
		foreach($posts as $post){
				$numberOfLikesAndDislikes = numberOfLikes($post['id']) + numberOfDislikes($post['id']);
				$numberOfComments = numberOfComments($post['id']);
				$post_id[] = $post['id'];
				$numberOfReactions[] = $numberOfLikesAndDislikes + $numberOfComments;
				$numberOfPostsTrending++;
		}
		
		if($numberOfPostsTrending > 10)
			$numberOfPostsTrending = 10;
		
		$_SESSION['first_news']="set";
		
		include ('templates/index.php');
		include ('templates/footer.php');
?>
