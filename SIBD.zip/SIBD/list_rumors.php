<?php
		session_start();
		include ('config/init.php');
		include ('templates/header.php');
		include ('database/rumor.php');
		include ('database/like_dislike.php');
		
		if(exist_rumor()){
		$rumors = list_rumors();
		include ('templates/list_rumors.php');}
		
		else 
			echo ("No rumors uploaded yet...");
		
		include ('templates/footer.php');
?>