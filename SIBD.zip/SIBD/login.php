 <?php
		include ('templates/header.php');
		include ('templates/login.php');
		include ('templates/footer.php');
  ?>