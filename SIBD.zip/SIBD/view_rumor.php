 <?php
		include ('templates/header.php');
		include('templates/view_rumor.php');
		include('templates/footer.php');
  ?>