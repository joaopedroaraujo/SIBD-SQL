<?php
		session_start();
		include ('config/init.php');
		include ('templates/header.php');
		include_once ('database/post.php');
		include_once ('database/like_dislike.php');
		include_once ('database/comment.php');
		
		$category=$_GET['category'];
		
		if(exist_post_in_category($category)){
			$posts = list_posts_by_category($category);
		include ('templates/list_posts.php');}
		
		else 
			echo ("No post uploaded yet to this category...");
		
		include ('templates/footer.php');
?>