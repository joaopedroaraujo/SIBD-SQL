<?php ?>
		<nav>
			<header id = "usersHeader" ><b>Users</b></header>
			<?php foreach ($users as $user) {?>
			<div id = "listUsers">
			<?php if(!isAdmin($user['username'])) : ?>
				<a href="profile.php?owner_id=<?=$user['username']?>"><img src="images/user/thumbs_small/<?=$user['username']?>.jpg"></a>
				<?php endif; ?>
				<a href="profile.php?owner_id=<?=$user['username']?>"><b><?= $user['username']?></b></a>
				<br>
			</div>
		</nav>
<?php } ?>