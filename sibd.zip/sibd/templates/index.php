	  
		<div id = "HomePage">
			<div id = "TrendingNews">
				<header id = "hdrtrnd">
					<p>Most Reacted</p>
				</header>
				<?php for($i = 0; $i < $numberOfPostsTrending; $i++){ 
				$maxs = array_keys($numberOfReactions, max($numberOfReactions));
				$id = $post_id[$maxs[0]];
				$post = getPostById($id);?>
				<article id="firstnews">
					<header>
						<h1><a href="view_post.php?post_id=<?=$post['id']?>&type=<?=$post['type']?>"><?= $post['title'];?></a></h1>
					</header>
					<img src="images/post/<?=$post['type']?>/display_images/<?=$post['id']?>.jpg"></a>
					<p id="type"><b>Type:</b><a href="list_posts.php?type=<?=$post['type']?>"><?= $post['type'];?></a></p>
					<div id = "hoverLC">
						<a href="view_post.php?post_id=<?=$post['id']?>&type=<?=$post['type']?>"><p id = "likeHover">Likes:<?= numberOfLikes($post['id'])?></p> <p id = "dislikeHover"> Dislikes:<?= numberOfDislikes($post['id'])?></p>
						<p id = "commentHover">Comments:<?=numberOfComments($post['id'])?></p>
					</div>
				</article>
				<?php unset($numberOfReactions[$maxs[0]]);}
				unset($_SESSION['first_news'])?>
			</div>
			
			<div id = "LatestNews">
				<header id = "hdrltst">
					<p>Latest uploads</p>
				</header>
				<?php foreach($lattests as $lattest){?>
				<article>
					<header>
						<h1><a href="view_post.php?post_id=<?=$lattest['id']?>&type=<?=$lattest['type']?>"><?= $lattest['title'];?></a></h1>
					</header>  
					<img src="images/post/<?=$lattest['type']?>/display_images/<?=$lattest['id']?>.jpg"></a>
					<p id="type"><b>Type:</b><a href="list_posts.php?type=<?=$lattest['type']?>"><?= $lattest['type'];?></a></p>
					<div id = "hoverLC">
						<a href="view_post.php?post_id=<?=$lattest['id']?>&type=<?=$lattest['type']?>"><p id = "likeHover">Likes:<?= numberOfLikes($lattest['id'])?></p> <p id = "dislikeHover"> Dislikes:<?= numberOfDislikes($lattest['id'])?></p>
						<p id = "commentHover">Comments:<?=numberOfComments($lattest['id'])?></p>
					</div>
				</article>
				<?php unset($numberOfReactions[$maxs[0]]);}
				unset($_SESSION['first_news'])?>
				</article>
			</div>
		</div></a>
	  
