<?php 
	if (session_status() == PHP_SESSION_NONE) {
    session_start();
	}
?>

<!DOCTYPE html> 
<html lang="en">
  <head>
      <link href="css/style.css" rel="stylesheet">
      <meta charset="UTF-8">
	  <meta http-equiv='cache-control' content='no-cache'>
		<meta http-equiv='expires' content='0'>
		<meta http-equiv='pragma' content='no-cache'>
	  <script src="script.js" defer></script>
      <title>TechLatest</title>
  </head>
  <body>
	<?php if(isset($_SESSION['ok'])) : ?>
		<div id="signup">
			<?php if($_SESSION['admins']===1) : ?>
			<a href="upload_post.php?type=news"><button>Upload news</button></a>
			<?php endif; ?>
			<a href="upload_post.php?type=rumor"><button>Upload rumor</button></a>
			<?php if($_SESSION['admins']===0) : ?>
			<a href="profile.php?owner_id=<?= $_SESSION['username']?>"><img src="images/user/thumbs_small/<?php echo($_SESSION['username']) ?>.jpg"></a>
			<?php endif; ?>
			<a href="profile.php?owner_id=<?= $_SESSION['username']?>"><?= $_SESSION['username']?></a>
			<a href="action_logout.php">Logout</a>
		</div>
	<?php else : ?>
		<div id="signup">
			<a href="register.php">Register</a>
			<a href="login.php">Login</a>
		</div>
	<?php endif; ?>
    <nav>
          <table>
              <tr>
                  <th><a href="list_posts_category.php?category=smartphones">Smartphones</a></th>
                  <th><a href="list_posts_category.php?category=computers">Computers</a></th>
                  <th><a href="list_posts_category.php?category=tablets">Tablets</a></th>
                  <th><a href="list_posts_category.php?category=google">Google</a></th>
                  <th><a href="list_posts_category.php?category=apple">Apple</a></th>
                  <th><a href="list_posts_category.php?category=android">Android</a></th>
                  <th><a href="list_posts_category.php?category=ios">iOS</a></th>
                  <th><a href="list_posts_category.php?category=others">Others</a></th>
              </tr>
          </table>
      </nav>
      <div id="title">
        <header>
            <h1><a href="index.php">TechLatest</a></h1>
            <h2><a href="index.php">News and rumors you care about</a></h2>
        </header>
      </div>
      <nav>
          <table>
              <tr>
                  <th><a href="list_posts.php?type=news">News</a></th>
				  <th><a href="list_posts.php?type=rumor">Rumors</a></th>
                  <th><a href="list_following.php">Following</a></th>
                  <th><form action="action_search.php" method="GET">
						<input type="text" name="query" placeholder="Category, title, user, ..."/>
						<input type="submit" value="Search"/>
					   </form></th>
              </tr>
          </table>
      </nav>
	  <div id = "NoteMsg">
		<div id = "success">
		<?php if(isset($_SESSION['success_message'])){
			
				echo $_SESSION['success_message'];
				unset($_SESSION['success_message']);
		}?>
		</div>
		<div id = "error">
		<?php if(isset($_SESSION['error_message'])){
				echo $_SESSION['error_message'];
				unset($_SESSION['error_message']);
		}?>
		</div>
	  </div>