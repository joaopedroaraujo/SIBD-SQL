<div id = "profile">
<?php if(isset($_SESSION['username'])):
	$username = $_SESSION['username'];?>
	<?php if($owner === $username) : // if the user wants to go to his own profile' ?>
		<a href="confirm_password.php"><input type="button" value="Edit profile"></a>
		<a href="action_remove.php?entity=user"><button>Delete account</button></a>
	<?php endif; ?>
	<?php if($owner !== $username) :?>
		<?php if(!isFollowing($username, $owner)) :?>
			<a href="action_follow.php?owner=<?= $owner ?>"><button>Follow</button></a>
		<?php else :?>
			<a href="action_follow.php?owner=<?= $owner ?>"><button>Stop following</button></a>
		<?php endif; ?>
	<?php endif; ?>
	<?php if(isAdmin($username) &&  $owner !== $username) :?>
		<a href="action_remove.php?entity=user"><button>Remove user</button></a>
	<?php endif; ?>
		<br>
	<?php if(!isAdmin($username)) : ?>
		<img src="images/user/thumbs_medium/<?= $owner?>.jpg"></a>
	<?php endif; ?>
		<p><b><?= $owner?></b></p>
		<?php $final = date("d M Y", strtotime(accountCreationTime($owner)));?>
	    <p><b>Member since:<?= $final?></b></p>
	<p><b>Evaluation:<?= round($userEvaluation, 2) ?></b></p>
<?php else :?>
	<img src="images/user/thumbs_medium/<?= $owner?>.jpg"></a>
	<p><b><?= $owner?></b></p>
	<?php $final = date("d M Y", strtotime(accountCreationTime($owner)));?>
	<p><b>Member since:<?= $final?></b></p>
	<p><b>Evaluation:<?= round($userEvaluation, 2) ?></b></p>
<?php endif; ?>
</div>