<section id="following">
	<?php foreach($masters as $master){
		  $posts = getPostsByUser($master['master']);?>
		 
		  
				<?php foreach($posts as $post){?>
				<div id = "follow">
				  <article>
					  <header id = "followhdr">
						<h1><a href="view_post.php?post_id=<?=$post['id']?>&type=<?=$post['type']?>"><?= $post['title'];?></a></h1>
					  </header>
					  <a id = "followImg" href="view_post.php?post_id=<?=$post['id']?>&type=<?=$post['type']?>"><img src="images/post/<?=$post['type']?>/display_images/<?=$post['id']?>.jpg"></a>
					  <p id = "followType"><b>Type:</b><a href="list_posts.php?type=<?=$post['type']?>"><?= $post['type'];?></a></p>
				  </article>
				  </div>
				<?php } ?>
			
		  
	<?php } 
		include ('templates/footer.php');?>
	  </article>
 </section>