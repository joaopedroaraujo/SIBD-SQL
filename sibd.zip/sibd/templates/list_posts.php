<?php ?>
		<nav>
			<?php if(isset($_SESSION['search'])) : 
			unset($_SESSION['search']); ?>
			<header id = "postsHeader"><b>Posts</b> </header>
			<br>
			<?php endif; ?>
			<?php foreach ($posts as $post) { 
			$type=$post['type'];?>
			<div id = "post">
				<a id = "postImage" href="view_post.php?post_id=<?=$post['id']?>&type=<?=$type?>"><img src="images/post/<?=$type?>/display_images/<?=$post['id']?>.jpg"></a>
				<label id = "postTitle"><a href="view_post.php?post_id=<?=$post['id']?>"><?=$post['title']?></a></label>
				<br>
				<label id = "postCateg">
					<?php if(isset($category)) : ?>
					<label><a href="list_posts.php?type=<?=$post['type']?>"><?=$post['type']?></a></label>
					<?php else : ?>
						<label><b>Category:</b><a href="list_posts_category.php?category=<?=$post['category']?>"><?=$post['category']?></a></label>
					<?php endif; ?>
				</label>
				</br>
				<p id = "likes"><b>Likes:</b><?= numberOfLikes($post['id'])?></p> <p id = "dislikes"> <b>Dislikes:</b><?= numberOfDislikes($post['id'])?><p>
				<p id = "comments"><b>Comments:</b><?=numberOfComments($post['id'])?></p>
			</div>
		</nav>
		
<?php } ?>