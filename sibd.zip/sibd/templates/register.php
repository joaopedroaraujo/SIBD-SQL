<form method="post" action="action_register.php" enctype="multipart/form-data">
  <div class="container">
	<label><b>Profile picture (optional)</b></label>
	<input type="file" name="image">
	<br>
	<label><b>Username</b>
		<input type="text" placeholder="Enter Username" name="username" required>
	</label>
		<br>
	<label><b>Password</b>
		<input type="password" placeholder="Enter Password" name="password" required>
	</label>
		<br>
	<label><b>Repeat Password</b>
		<input type="password" placeholder="Repeat Password" name="password_repeat" required>
	</label>
	<br>
	<a href="index.php"><button type="button"  class="cancelbtn">Cancel</button></a>
	<button type="submit">Create account</button>
  </div>
</form>


