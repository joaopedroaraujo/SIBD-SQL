<form method="post" action="action_profile_edits.php" enctype="multipart/form-data">
  <div class="container">
	<label><b>Profile picture:</b><label>
		<input type="file" name="image">
	<br>
	<button type="submit">Save</button>
  </div>
</form>
<br>
<form method="post" action="action_save_edits.php" id = "changePass">
	<label><b>Password:</b>
		<input type="password" placeholder="Enter Password" name="password" required>
	</label>
		<br>
	<label><b>Repeat Password:</b>
		<input type="password" placeholder="Repeat Password" name="password_repeat" required>
	</label>
	<br>
	<button type="submit">Save</button>
 <!-- </div> -->
</form>
<div id = "cnclbnt">
	<p><a href="profile.php?owner_id=<?= $_SESSION['username']?>"><button type="button"  class="cancelbtn">Go back</button></a></p>
</div>