<form method="post" action="action_confirm_password.php">
	<div id="confpass">
		<label><b>Please enter your password:</b></label>
		<input type="password" name="password" required>
		<br>
		<button id = "nextbtn" type="submit">Next</button>
		<div id = "cnclbtn">
		<p><a href="profile.php?owner_id=<?= $_SESSION['username']?>"><button type="button"  class="cancelbtn">Cancel</button></a></p>
	</div>
	</div>
	
</form>