<?php
	include ('config/init.php');
	include ('database/user.php');

	$username = $_SESSION['username'];
	$password = $_POST['password'];
	if (isValidUser($username, $password)){
		header('Location: edit_profile.php');
	}
		
	else {
		$_SESSION['error_message'] = "Wrong password!";
		header("Location: profile.php?owner_id=$username");
	}
?>