<?php 
	if (isset($_SESSION['username']))
		$user_id = $_SESSION['username'];
?>
<article>
  <header>
	<?php if (isset($_SESSION['username'])) : ?>
		<?php if($_SESSION['admins']===1 || $post['user_id'] === $user_id) :?>
			<a href="action_remove.php?entity=post"><button>Remove post</button></a>
		<?php endif; ?>
	<?php endif; ?>
	<h1><?= $post['title']?></h1>
	<h2><?= $post['category']?></h2>
  </header>
  <img src="images/post/<?=$type?>/display_images/<?=$post_id?>.jpg">
  <p><?php echo $post['text'] ?></p>
  <p>
	<?="by"?> 
	<a href="profile.php?owner_id=<?=$post['user_id']?>"><?=$post['user_id']?></a>
	<?="on"?> 
	<?php 
		$datetime = strtotime($post['date_time']);
		$final = date("l - d M Y, h:m A", $datetime);
	?>
	<?=$final?>
  </p>
  <?php if (!isset($user_id)) : ?>
  <p><a href="register.php">Register</a> or <a href="login.php">login<a> to share an opinion! </p>
  <?php endif; ?>
  <p>Likes:<?= numberOfLikes($post_id)?> Dislikes:<?= numberOfDislikes($post_id)?><p>
  <?php if (isset($user_id)) : ?>
	  <?php if(!liked($post_id, $user_id)) : ?>
		<!--<button onClick="like">Like</button> fazer com js se tiver tempo--> 
		<a href="action_like.php"><button>Like</button></a>
	  <?php else : ?>
		<a href="action_like.php"><button>Liked</button>
	  <?php endif ;?>
	  <?php if(!disliked($post_id, $user_id)) : ?>
		<a href="action_dislike.php"><button>Dislike</button></a>
	  <?php else : ?>
		<a href="action_dislike.php"><button>Disliked</button></a>
	  <?php endif ;?>
	  <br>
	  <section id="comments">
		  <!--<form method="post" action="action_comment.php">-->
		  <form>
			  <header><b>Comments:</b></header>
			  <br>
			  <textarea rows="7" cols="150" name="comment" required></textarea>
			  <br>
			  <input type="submit" value="Submit comment">
		  </form>
		  <div id="list_comments">
		   <?php $comments = list_comments($post_id); ?>
			<?php foreach ($comments as $comment) { ?>
				<?php if (isset($_SESSION['username'])) : ?>
					<?php if($_SESSION['admins']===1 || $comment['user_id']=== $user_id) :?>
					<a href="action_remove.php?entity=comment<?=$comment['id']?>"><button>X</button></a>
					<?php endif; ?>
				<?php endif; ?>
				<br>
				<a href="profile.php?owner_id=<?=$comment['user_id']?>"><?=$comment['user_id']?></a>
				<p><?=$comment['comment']?></p>
				<?php } ?>
				<div>
		<?php else : ?>
		<article>
			<header><b>Comments:</b></header>
			<?php $comments = list_comments($post_id); ?>
			<?php foreach ($comments as $comment) { ?>
				<a href="profile.php?owner_id=<?=$comment['user_id']?>"><?=$comment['user_id']?></a>
				<p><?=$comment['comment']?></p>
			<?php } ?>
		</article>
	  </section>
	<?php endif ;?>
</article>