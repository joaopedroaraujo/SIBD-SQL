	<body>
		<form method="post" action="action_login.php">
		  <div class="container">
			<label><b>Username</b>
				<input type="text" placeholder="Enter Username" name="username" required>
			</label>
				<br></br>
			<label><b>Password</b>
				<input type="password" placeholder="Enter Password" name="password" required>
			</label>
				<br></br>
			<div class="clearfix">
			  <a href="index.php"><button type="button"  class="cancelbtn">Cancel</button></a>
			  <button type="submit" class="signupbtn">Login</button>
			</div>
		  </div>
		</form>
	</body>