<form action="action_upload_profile_image.php" method="post" enctype="multipart/form-data">
	<p>Profile picture (optional)</p>
	<input type="file" name="image">
	<br>
	<input type="submit" value="Register">
</form>