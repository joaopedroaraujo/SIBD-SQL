let commentForm = document.querySelector('#comments form');
commentForm.addEventListener('submit', submitComment);

let commentsArticle = document.querySelector('#comments div form');
commentsArticle.addEventListener('submit', removeComment);

function removeComment(event) {
	console.log("entrou");
	let entity = document.querySelector('#comments input[name="entity"]').value;
	let request = new XMLHttpRequest();
	console.log(entity);
	//request.addEventListener('load', loadDeleteComment);
	request.open('POST', 'action_remove.php', true);
	request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	request.send(encodeForAjax({entity : entity}));
	//event.preventDefault();
}

function loadDeleteComment(event) {
	let node = document.getElementById("list_comments");
	node.removeChild(node.childNodes[3]);
	node.removeChild(node.childNodes[2]);
	node.removeChild(node.childNodes[1]);
	
}

function encodeForAjax(data) {
  return Object.keys(data).map(function(k){
    return encodeURIComponent(k) + '=' + encodeURIComponent(data[k])
  }).join('&');
}

function submitComment(event) {
  /*let id = document.querySelector('#comments input[name=id]').value;
  let username = document.querySelector('#comments input[name=username]').value;*/
  let comment = document.querySelector('#comments textarea[name=comment]').value;
  //let comment_id = document.querySelector('#comments .comment') != null ? document.querySelector('#comments .comment:last-of-type span.id').textContent : -1;


  let request = new XMLHttpRequest();
  request.addEventListener('load', receiveComments);
  request.open('POST', 'action_comment.php', true);
  request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  request.send(encodeForAjax({comment : comment}));

  event.preventDefault();
}

function receiveComments(event) {
  let comments = JSON.parse(this.responseText);
  let comment = document.createElement('div');
  

  //for (let i = 0; i < comments.length; i++) {
	//comment = document.createElement('article');
	comment.classList.add('comment');

    /*comment.innerHTML = '<form>' + '<input type="hidden" name="entity" value="' + comments[0].user_id + '">' +
	'<input type="submit" value="X"/>'
	+ '</form><br>' +
	'<a class="id" href="profile.php?owner_id=' + comments[0].user_id + '">' +
	comments[0].user_id + '</a><p>' +
      comments[0].comment + '</p>';*/
	  
	comment.innerHTML = '<a href="action_remove.php?entity=comment' + comments[0].user_id +'"><button>X</button></a><br><a class="id" href="profile.php?owner_id=' + 
	comments[0].user_id + '">' +
	comments[0].user_id + '</a><p>' +
	comments[0].comment + '</p>';
	
   insertAfter(comment, commentForm);
   document.querySelector('#comments textarea[name=comment]').value = ''; // cleaning text area after submitting comment
  //}
}
  
function insertAfter(newNode, referenceNode) {
    referenceNode.parentNode.insertBefore(newNode, referenceNode.nextSibling);
	}