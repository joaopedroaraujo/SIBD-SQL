<?php
  include ('config/init.php');
  include ('database/user.php');
  
  if(isset($_POST['password'])){
	$password = $_POST['password'];
    $password_repeat = $_POST['password_repeat'];
	if ($password !== $password_repeat){
		$_SESSION['error_message'] = 'Passwords must be the same';
		die(header('Location: edit_profile.php'));
	}
	$username = $_SESSION['owner'];
	updatePassword($username, $password);
	header('Location: index.php');
  }
  
  include ('action_upload_profile_image.php');

  /*$username = strip_tags($_POST['username']);
  $password = $_POST['password'];
  $password_repeat = $_POST['password_repeat'];

  if (!$username || !$password) {
    $_SESSION['error_message'] = 'All fields are mandatory!';
    $_SESSION['form_values'] = $_POST;
    die(header('Location: register.php'));
  }
  
  try {
    createUser($username, $password, $password_repeat);
    $_SESSION['success_message'] = 'User registered with success!';
  } catch (PDOException $e) {

    if (strpos($e->getMessage(), 'users_pkey') !== false)
      $_SESSION['error_message'] = 'Username already exists!';
	  
    else
      $_SESSION['error_message'] = 'FAILLL!';

    $_SESSION['form_values'] = $_POST;
   die(header('Location: register.php'));
  }*/
  
?>