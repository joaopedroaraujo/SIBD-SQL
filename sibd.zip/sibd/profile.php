<?php
	include ('config/init.php');
	include ('templates/header.php');
	include_once ('database/like_dislike.php');
	include_once ('database/user.php');
	include_once ('database/post.php');
	include_once ('database/follows.php');

	$owner=$_GET['owner_id'];
	$_SESSION['owner'] = $owner;
		
	$n_likes=0;
	$n_dislikes=0;	
	$posts=getPostsByUser($owner);
	foreach ($posts as $post){
			$post_id=$post['id'];
			$n_likes=$n_likes+numberOfLikes($post_id);
			$n_dislikes=$n_dislikes+numberOfDislikes($post_id);
		}

	if(($n_likes+$n_dislikes)===0) $userEvaluation = 0;
	else $userEvaluation = ((($n_likes-$n_dislikes)/($n_likes+$n_dislikes))*100);
		
	include ('templates/profile.php');
	include ('templates/footer.php');
?>