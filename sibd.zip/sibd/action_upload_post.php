<?php
  session_start();
  include ('config/init.php');
  include ('database/post.php');

  $type = $_GET['type'];
  $_SESSION['type'] = $_GET['type'];
  $category = $_POST['category'];
  $title = $_POST['title'];
  $text = $_POST['text'];
  $username = $_SESSION['username'];
  
  uploadPost($type, $category, $title, $text, $username);
  $_SESSION['success_message'] = "$type uploaded with sucess!";
  
  $id = $conn->lastInsertId();
  $_SESSION['id'] = $id;

    // Generate filenames for original, small and medium files
    $originalFileName = "images/post/$type/original/$id.jpg";
	$mediumFileName = "images/post/$type/display_images/$id.jpg";

    // Move the uploaded file to its final destination
    if(file_exists($_FILES['image']['tmp_name']) || is_uploaded_file($_FILES['image']['tmp_name'])){
	  move_uploaded_file($_FILES['image']['tmp_name'], $originalFileName);
	}
    else{
	  copy("images/post/default/default.jpg", "images/post/$type/original/$id.jpg");
	}

    // Crete an image representation of the original image
    $original = imagecreatefromjpeg($originalFileName);

    $width = imagesx($original);     // width of the original image
    $height = imagesy($original);    // height of the original image
    $square = min($width, $height);  // size length of the maximum square

	 // Calculate width and height of medium sized image (max width: 400)
	$mediumwidth = $width;
	$mediumheight = $height;
	if ($mediumwidth > 400) {
		$mediumwidth = 400;
		$mediumheight = $mediumheight * ( $mediumwidth / $width );
	}
	
    // Create and save a medium image
    $medium = imagecreatetruecolor($mediumwidth, $mediumheight);
    imagecopyresized($medium, $original, 0, 0, 0, 0, $mediumwidth, $mediumheight, $width, $height);
    imagejpeg($medium, $mediumFileName);
  
	header('Location: list_posts.php');
?>