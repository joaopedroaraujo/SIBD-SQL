<?php
		include ('templates/header.php');
		include ('templates/register2.php');
		include ('templates/footer.php');
?>