<?php
		include ('templates/header.php');
		include ('templates/confirm_password.php');
		include ('templates/footer.php');
?>