<?php
  include ('config/init.php');
  include ('database/user.php');
  
  $_SESSION['search'] = "set";
  $query = $_GET['query'];
         
	$query = htmlspecialchars($query); 
	// changes characters used in html to their equivalents, for example: < to &gt;		 
	
	if($query === ""){
		include ('templates/header.php');
		echo "No results found...";
		include ('templates/footer.php');
		die();
	}
		 
	global $conn;
	$stmt = $conn->prepare('SELECT * FROM posts WHERE (type LIKE ?) OR (category LIKE ?) OR (title LIKE ?) 
							OR (user_id LIKE ?) ORDER BY id DESC');
	$stmt->execute(array("%" . $query . "%", "%" . $query . "%", "%" . $query . "%", "%" . $query . "%"));
	
	if($stmt->rowCount() > 0)
		$posts = $stmt->fetchAll();
	
	$stmt = $conn->prepare('SELECT * FROM users WHERE username LIKE ?');
	$stmt->execute(array("%" . $query . "%"));
	if($stmt->rowCount() > 0)
		$users = $stmt->fetchAll();
	
	include ('list_search.php');
	
	// * means that it selects all fields, you can also write: `id`, `title`, `text`
	// articles is the name of our table
	 
	// '%$query%' is what we're looking for, % means anything, for example if $query is Hello
	// it will match "hello", "Hello man", "gogohello", if you want exact match use `title`='$query'
	// or if you want to match just full word so "gogohello" is out use '% $query %' ...OR ... '$query %' ... OR ... '% $query'
?>