 <?php
		include ('templates/header.php');
		include ('templates/edit_profile.php');
		include ('templates/footer.php');
  ?>