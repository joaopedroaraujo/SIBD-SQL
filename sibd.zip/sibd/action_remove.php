<?php
  session_start();
  include ('config/init.php');
  include_once ('database/comment.php');
  include_once ('database/post.php');
  include_once ('database/user.php');

  $remove = $_GET['entity'];
  if(isset($_SESSION['type']))
	$type = $_SESSION['type'];
  $remove_comment = substr($remove, 0, 7);
  //$remove_comment = $_POST['entity'];
  if(isset($_SESSION['post_id']))
	$post_id = $_SESSION['post_id'];
  $user_id = $_SESSION['username'];
  if(isset($_SESSION['owner']))
	$owner = $_SESSION['owner'];
  
  if($remove_comment == "comment"){
	$comment_id = substr($remove, 7);
	//$number = getCommentNumber($remove_comment);
	removeComment($comment_id);
	$_SESSION['success_message']="Comment removed!";
	header('Location: ' . $_SERVER['HTTP_REFERER']);
	//echo json_encode($number);
  }
  
  if ($remove === "post"){
	removePost($post_id, $type);
	$_SESSION['success_message']="Post removed!";
	header("Location: list_posts.php?type=$type");
  }
  if ($remove === "user"){
	if(isAdmin($user_id)){
		$user_id = $owner;
		removeUser($user_id);
		$_SESSION['success_message']="User removed!";
		header('Location: index.php');
	}
	else{
		removeUser($user_id);
		$_SESSION['success_message']="User removed!";
		include ('action_logout.php');
	}
  }

?>