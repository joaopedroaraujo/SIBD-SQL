<?php
		session_start();
		include ('config/init.php');
		include ('templates/header.php');
		include_once ('database/follows.php');
		include_once ('database/post.php');
		
		$slave=$_SESSION['username'];
		$masters = getAllMasters($slave);
		if(count($masters) === 0){
			echo "You are not following anyone or the users you are following have not posted anything yet...";
			include ('templates/footer.php');
		}
		else include ('templates/list_following.php');
?>