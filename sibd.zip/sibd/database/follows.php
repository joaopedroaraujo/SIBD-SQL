<?php
	function isFollowing($slave, $master){
		global $conn;
		$stmt = $conn->prepare('SELECT * FROM follows WHERE slave = ? AND master = ?');
		$stmt->execute(array($slave, $master));
		if ($stmt->rowCount() > 0) return true;
		else return false; 
	}

	function startFollowing($slave, $master){
		global $conn;
		$stmt = $conn->prepare('INSERT INTO follows VALUES (DEFAULT, ?, ?)');
		$stmt->execute(array($slave, $master));
	}
	
	function stopFollowing($slave, $master){
		global $conn;
		$stmt = $conn->prepare('DELETE FROM follows WHERE slave = ? AND master = ?');
		$stmt->execute(array($slave, $master));
	}
	
	function numberOfFollowers($master){
		global $conn;
		$stmt = $conn->prepare('SELECT * FROM follows WHERE master = ?');
		return $stmt->rowCount();
	}
	
	function getAllMasters($slave){
		global $conn;
		$stmt = $conn->prepare('SELECT * FROM follows WHERE slave = ?');
		$stmt->execute(array($slave));
		return $stmt->fetchAll();
	}
?>