<?php 
	function addComment($post_id, $comment, $user_id){
		global $conn;
		$stmt = $conn->prepare('INSERT INTO comments VALUES (DEFAULT, ?, ?, NOW(), ?)');
		$stmt->execute(array($post_id, $comment, $user_id));
	}
	
	function list_comments($post_id){
	global $conn;
	$stmt = $conn->prepare('SELECT * FROM comments WHERE post_id = ? ORDER BY id DESC');
	$stmt->execute(array($post_id));
    return $stmt->fetchAll();
  }
  
    function numberOfComments($post_id){
		global $conn;
		$stmt = $conn->prepare('SELECT * FROM comments WHERE post_id = ?');
		$stmt->execute(array($post_id));
		$numberOfComments=$stmt->rowCount();
		return $numberOfComments;
	}
	
	function removeComment($comment_id){
		global $conn;
		$stmt = $conn->prepare('DELETE FROM comments WHERE id = ?');
		$stmt->execute(array($comment_id));
	}
	
	function removeAllPostComment($post_id){
		global $conn;
		$stmt = $conn->prepare('DELETE FROM comments WHERE post_id = ?');
		$stmt->execute(array($post_id));
	}
	
	function getCommentNumber($comment_id){
		global $conn;
		$stmt = $conn->query('SELECT * FROM comments');
		$comments = $stmt->fetchAll();
		$i=0;
		foreach ($comments as $comment){
			if($comment_id === $comment['id']);
			$i++;
			break;
		}
		return $i;
	}
?>