CREATE TABLE users (
  username VARCHAR PRIMARY KEY,
  password VARCHAR,
  admins INTEGER,
  date_time TIMESTAMP
);

CREATE TABLE posts (
  id SERIAL PRIMARY KEY,
  type VARCHAR, --rumor or news
  category VARCHAR,
  title VARCHAR,
  text VARCHAR,
  date_time TIMESTAMP,
  user_id VARCHAR REFERENCES users
);

CREATE TABLE likes_dislikes (
  id SERIAL PRIMARY KEY,
  post_id INTEGER REFERENCES posts,
  likes INTEGER,
  dislikes INTEGER,
  date_time TIMESTAMP,
  user_id VARCHAR
);

CREATE TABLE comments (
  id SERIAL PRIMARY KEY,
  post_id INTEGER REFERENCES posts,
  comment VARCHAR,
  date_time TIMESTAMP,
  user_id VARCHAR
);

CREATE TABLE follows (
  id SERIAL PRIMARY KEY,
  slave VARCHAR,
  master VARCHAR
);

INSERT INTO users  VALUES ('ppinto','$2y$12$Layk.bcQLBGM5bodjPJbjORSUq1RwFDMKzfsrqLtX1obpzmK2mrB.', 1, NOW()); /* ppinto */
INSERT INTO users  VALUES ('jaraujo','$2y$12$aDUpNopPWRZ987j/aa55/OhHNd0wW9S9CSXai7SX86ygjDbHFx/UG', 1, NOW()); /* jaraujo */

/* 
	SmartphoneWise - smartphonewise
	PcOlid - pcolid
	TechJoy - techjoy
	BitStoic - bitstoic
	IAit - iait
	HaftPad - haftpad
	NewsEriel - newseriel
	
*/






