<?php

	function liked($post_id, $user_id){
		global $conn;
		$stmt = $conn->prepare('SELECT * FROM likes_dislikes WHERE post_id = ? AND user_id = ?');
		$stmt->execute(array($post_id, $user_id));
		$like=$stmt->fetch();
		if($like['likes'] === 1) return true;
		else return false;
	}

	function addLike($post_id, $user_id){
		removeLike_Dislike($post_id, $user_id);
		global $conn;
		$stmt = $conn->prepare('INSERT INTO likes_dislikes VALUES (DEFAULT, ?, 1, 0, NOW(), ?)');
		$stmt->execute(array($post_id, $user_id));
	}
	
	function disliked($post_id, $user_id){
		global $conn;
		$stmt = $conn->prepare('SELECT * FROM likes_dislikes WHERE post_id = ? AND user_id = ?');
		$stmt->execute(array($post_id, $user_id));
		$dislike=$stmt->fetch();
		if($dislike['dislikes'] === 1)
			return true;
		else return false;
	}
	
	function addDislike($post_id, $user_id){
		removeLike_Dislike($post_id, $user_id);
		global $conn;
		$stmt = $conn->prepare('INSERT INTO likes_dislikes VALUES (DEFAULT, ?, 0, 1, NOW(), ?)');
		$stmt->execute(array($post_id, $user_id));
	}

	function removeLike_Dislike($post_id, $user_id){
		global $conn;
		$stmt = $conn->prepare('DELETE FROM likes_dislikes WHERE post_id = ? AND user_id = ?');
		$stmt->execute(array($post_id, $user_id));
	}
	
	function removeAllPostLike_Dislike($post_id){
		global $conn;
		$stmt = $conn->prepare('DELETE FROM likes_dislikes WHERE post_id = ?');
		$stmt->execute(array($post_id));
	}
	
	function numberOfLikes($post_id){
		global $conn;
		$stmt = $conn->prepare('SELECT * FROM likes_dislikes WHERE post_id = ? AND likes = 1');
		$stmt->execute(array($post_id));
		$numberOfLikes=$stmt->rowCount();
		return $numberOfLikes;
	}
	
	function numberOfDislikes($post_id){
		global $conn;
		$stmt = $conn->prepare('SELECT * FROM likes_dislikes WHERE post_id = ? AND dislikes = 1');
		$stmt->execute(array($post_id));
		$numberOfLikes=$stmt->rowCount();
		return $numberOfLikes;
	}
?>