<?php
  include_once ('database/post.php');

  function isValidUser($username, $password) {
    global $conn;
	
    $stmt = $conn->prepare('SELECT * FROM users WHERE username = ?');
    $stmt->execute(array($username));
   
    $user = $stmt->fetch();
	$_SESSION['admins']=$user['admins'];

    return $user !== false && password_verify($password, $user['password']);
  }

  function createUser($username, $password, $password_repeat) {
	if ($password !== $password_repeat)	die(header('Location: register.php'));
	
    global $conn;

	$_SESSION['username'] = $username;
	$_SESSION['admins'] = 0;
	
    $options = [
        'cost' => 12,
    ];

    $hash = password_hash ($password , PASSWORD_DEFAULT, $options);

    $stmt = $conn->prepare('INSERT INTO users VALUES (?, ?, ?, NOW())');
    $stmt->execute(array($username, $hash, $_SESSION['admins']));
  }
  
  function isAdmin ($username){
	global $conn;
	
    $stmt = $conn->prepare('SELECT * FROM users WHERE username = ?');
    $stmt->execute(array($username));
	
    $user = $stmt->fetch();
	
	if($user['admins']===1) return true;
	
	else return false;
  }
  
  function removeUser($username){
		$posts = getPostsByUser($username);
		foreach ($posts as $post){
			removePost($post['id']);
		}
		global $conn;
		$stmt = $conn->prepare('DELETE FROM users WHERE username = ?');
		$stmt->execute(array($username));
		unlink("images/user/originals/$username.jpg");
		unlink("images/user/thumbs_medium/$username.jpg");
		unlink("images/user/thumbs_small/$username.jpg");
	}
	
	function accountCreationTime($username){
		global $conn;
		$stmt = $conn->prepare('SELECT * FROM users WHERE username = ?');
		$stmt->execute(array($username));
		$result = $stmt->fetch();
		return $result['date_time'];
	}
	
	function updatePassword($username, $password){
		global $conn;
		
		$options = [
        'cost' => 12,
		];

		$hash = password_hash ($password , PASSWORD_DEFAULT, $options);
		
		$stmt = $conn->prepare('UPDATE users SET password = ? WHERE username = ?');
		$stmt->execute(array($hash, $username));
	}
?>
