<?php
		session_start();
		include ('config/init.php');
		include ('templates/header.php');
		include_once ('database/post.php');
		include_once ('database/like_dislike.php');
		include_once ('database/comment.php');
		
		if(isset($_GET['type']))
			$type=$_GET['type'];
		else 
			$type=$_SESSION['type'];
		
		if(exist_post($type)){
			$posts = list_posts($type);
		include ('templates/list_posts.php');}
		
		else 
			echo ("No $type uploaded yet...");
		
		include ('templates/footer.php');
?>