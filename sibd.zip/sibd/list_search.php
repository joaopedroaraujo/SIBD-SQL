<?php
		include ('config/init.php');
		include ('templates/header.php');
		include_once ('database/post.php');
		include_once ('database/like_dislike.php');
		include_once ('database/comment.php');
		
		if(isset($users))
			include ('templates/list_users.php');
		
		if(isset($posts))
			include ('templates/list_posts.php');
		
		else echo "No results found";
		
		include ('templates/footer.php');
?>