<?php
  include ('config/init.php');
  session_destroy();
  session_start();
  $_SESSION['success_message']="Logged out with sucess!";
  header('Location: index.php');
?>
