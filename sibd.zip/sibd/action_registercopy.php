<?php
  include ('config/init.php');
  include ('database/user.php');

  $username = strip_tags($_POST['username']);
  $password = $_POST['password'];
  $password_repeat = $_POST['password_repeat'];

  if (!$username || !$password) {
    $_SESSION['error_message'] = 'All fields are mandatory!';
    $_SESSION['form_values'] = $_POST;
    die(header('Location: register.php'));
  }
  
  try {
    createUser($username, $password, $password_repeat);
    $_SESSION['success_message'] = 'User registered with success!';
  } catch (PDOException $e) {

    if (strpos($e->getMessage(), 'users_pkey') !== false)
      $_SESSION['error_message'] = 'Username already exists!';
	  
    else
      $_SESSION['error_message'] = 'FAILLL!';

    $_SESSION['form_values'] = $_POST;
   die(header('Location: register.php'));
  }
	header('Location: register2.php');
?>
